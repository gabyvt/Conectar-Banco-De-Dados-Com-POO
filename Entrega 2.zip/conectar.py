from pymongo import MongoClient

client = MongoClient('localhost', 27017)
db = client.exemplo
collection = db.Produto

def listar_databases():
    db_list = client.list_database_names()
    print(db_list)

def inserir_produto():
    for _ in range(4):
        marca = input("Digite a marca: ")
        modelo = input("Digite o modelo: ")
        qtd = input("Digite a qtd: ")
        preco = input("Digite o preco: ")

        doc = {"marca": marca, "modelo": modelo, "qtd": qtd, "preco": preco}
        collection.insert_one(doc)
    print("Produtos inseridos com sucesso!")

def atualizar_preco():
    marca_desejada = input("Qual marca deseja atualizar? ")
    modelo_desejado = input("Qual modelo deseja atualizar? ")
    novo_preco = input("Qual o novo preço? ")

    collection.update_one({"marca": marca_desejada, "modelo": modelo_desejado}, {"$set": {"preco": novo_preco}})
    print("Preço atualizado com sucesso!")

def buscar_produtos():
    marca = input("Digite a marca: ")
    modelo = input("Digite o modelo: ")
    
    for documento in collection.find({"marca": marca, "modelo": modelo}):
        print(documento)

def agregacao():
    # Seu código de agregação pode permanecer aqui

    pipeline = [
        {
            "$group": {
                "_id": "$preco",
                "produtos": {
                    "$push": {
                        "marca": "$marca",
                        "modelo": "$modelo",
                        "qtd": "$qtd",
                        "preco": "$preco"
                    }
                },
                "count": {"$sum": 1}
            }
        },
        {
            "$match": {
                "count": {"$gt": 1}
            }
        }
    ]

    for group in collection.aggregate(pipeline):
        print(f"Preço: {group['_id']}")
        for produto in group['produtos']:
            print(produto)
        print("--------------------")

def calcular_media_preco():
    pipeline = [
        {
            "$group": {
                "_id": None,
                "media_preco": {"$avg": "$preco"}
            }
        }
    ]

    resultados = list(collection.aggregate(pipeline))
    media = resultados[0]['media_preco'] if resultados else 0

    print(f"A média de preços dos produtos é: {media:.2f}")

# Menu
while True:
    print("\n--- Menu ---")
    print("1. Listar databases")
    print("2. Inserir produto")
    print("3. Atualizar preço de produto")
    print("4. Buscar produtos")
    print("5. Agregação")
    print("6. Calcular média de preço")
    print("7. Sair")

    opcao = input("Selecione uma opção: ")

    if opcao == "1":
        listar_databases()
    elif opcao == "2":
        inserir_produto()
    elif opcao == "3":
        atualizar_preco()
    elif opcao == "4":
        buscar_produtos()
    elif opcao == "5":
        agregacao()
    elif opcao == "6":
        calcular_media_preco()
    elif opcao == "7":
        client.close()
        break
    else:
        print("Opção inválida!")
